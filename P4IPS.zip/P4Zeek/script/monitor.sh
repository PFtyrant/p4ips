declare -i num=1000
# sleep 3
printf "CMD\tMEM\tCPU\n" > ../datas/monitor_log.txt

for ((i=3;i>=1;i--))
do
    echo "$i s"
    sleep 1
done

for ((i=1;i<=$num;i++))
do  
    # if [ "$i" -eq 1 ];
    # then
    #     # pidstat --no-headers -u -C P4Zeek_cp > ../datas/monitor_log.txt
    #     ps --no-headers -eo cmd,%mem,%cpu --sort=-%cpu | head -n 2 > ../datas/monitor_log.txt
    # else
    #     # pidstat --no-headers -u -C P4Zeek_cp >> ../datas/monitor_log.txt
    #     ps --no-headers -eo cmd,%mem,%cpu --sort=-%cpu | head -n 2 >> ../datas/monitor_log.txt
    # fi
    ps --no-headers -eo cmd,%mem,%cpu --sort=-%cpu | head -n 2 >> ../datas/monitor_log.txt
    sleep 0.000001
done